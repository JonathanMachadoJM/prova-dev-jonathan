import { initializeApp } from 'firebase/app';
import { getAuth } from '@firebase/auth';
import { getFirestore } from '@firebase/firestore';

const firebaseConfig = {
	apiKey: "AIzaSyD-vOYbHPSESrQUDjtPfER7VtGDjeyXBKM",
	authDomain: "prova-dev-jonathan.firebaseapp.com",
	projectId: "prova-dev-jonathan",
	storageBucket: "prova-dev-jonathan.appspot.com",
	messagingSenderId: "85861117892",
	appId: "1:85861117892:web:ed236bb8027e0632b6be91",
	measurementId: "G-PB95JM45VN"
};

const app = initializeApp(firebaseConfig);

export const db = getFirestore(app);

export const auth = getAuth(app);
console.log("app auth ", auth);
