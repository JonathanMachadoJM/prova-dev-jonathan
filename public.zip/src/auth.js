export const isAuthenticated = () => false;
