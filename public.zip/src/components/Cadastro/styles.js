import styled from "styled-components";

export const Bot = styled.img`
    height: 65px;
    width: 65px;
    display: flex;
    position: absolute;
    left: 29px;
    bottom: 5px;
`;
